<?php
  $server = "localhost";
  $username = "root";
  $password = "";
  $db = "groupe_individu";
  $conn = mysqli_connect($server, $username, $password, $db);
?>