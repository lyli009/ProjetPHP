<html>
    <head><title>Ajouter</title>  
	 <link rel="stylesheet" href="css/formulaire_style.css">
	 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">
	 
	</head>
    <body>
        
        <h1 class="title is-2"> Formulaire d'ajout </h1>

        <form class ="formulaire" name="inscription" method="post" action="formulaire_individu.php">
			<div>
				<label class="label">Nom</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="nom"  placeholder="Name"  required  />
			</div>
			<div>
			 
				<label class="label">Prénom</label>
			
				<input class="input" type="text" style="width: 350px; height: 35 px;"  name="prenom" placeholder="Surname" required />
			</div>
			<div>
				<label class="label">Numero ID</label>
				
				<input class="input" type="text" style="width: 350px; height: 35 px;"  name="numero" placeholder="ID" required />
			</div>
			<div> 
				<label class="label">Email</label>
  
                <input class="input" type="email" style="width: 350px; height: 35 px;"  name="email" placeholder="Email" required />
			</div>

			<div>
				<label class="label">Numero d'annuaire</label>
  
                <input class="input" type="text" style="width: 350px; height: 35 px;"  name="numero_annuaire" placeholder="Numero d'annuaire de reférence" required />
  
			</div>
			<div>
				<label class="label">Statut</label>
  
                <input class="input" type="text" style="width: 350px; height: 35 px;"  name="statut" placeholder="ETU, PR, MCF, VAC_EXT, VAC_INT, etc." required />
  
			</div>
			
			<div class="control">
				<button class="button is-primary" name="valider" >Valider</button>
			</div>
   
        </form>
		
		
		
    <?php
		include("db_connect.php");
		
		
        if(isset($_POST['valider'])){
          
			$nom=$_POST['nom'];
			$prenom =$_POST['prenom'];
			$numero=$_POST['numero'];
			$email=$_POST['email'];
			$numero_annuaire=$_POST['numero_annuaire'];
			$statut = $_POST['statut'];
			
		//verifier si l'individu existe deja
		$iindividu ='select * from individu where nom = "'.$nom.'"  and prenom ="'.$prenom.'" and numero = "'.$numero.'"';
		
		$result4 = mysqli_query($conn, $iindividu);
		  
		if ((mysqli_num_rows($result4) <= 0)) {
			  
			//verifier si le numero d'annuaire correspond a un numero existant et recuperer id
			$iannuaire = 'select id_annuaire from annuaire  where num_annuaire = "'.$numero_annuaire.'"';
			//meme chose pour le statut
			$istatut ='select id_statut from statut  where nom_statut = "'.$statut.'"';
			
			$result2 = mysqli_query($conn, $iannuaire);
			
			$result3 = mysqli_query($conn, $istatut);
			//si le numero d'annuaire n'existe pas on l'ajoute
			if (mysqli_num_rows($result2) <= 0){
				
				$sql1='INSERT INTO annuaire(num_annuaire) VALUES ("'.$numero_annuaire.'")';
				
				$var=mysqli_query($conn, $sql1);
				
				$iannuaire = 'select id_annuaire from annuaire  where num_annuaire = "'.$numero_annuaire.'"';
				
				$result2 = mysqli_query($conn, $iannuaire);
			}
				
			if (mysqli_num_rows($result3) <= 0){
					
					
				$sql2='INSERT INTO statut(nom_statut) VALUES ("'.$statut.'")';
					
				$var1=mysqli_query($conn, $sql2);
					
				$istatut ='select id_statut from statut  where nom_statut = "'.$statut.'"';
					
				$result3 = mysqli_query($conn, $istatut);
			}
			 
				$row = mysqli_fetch_array($result2) ;
				$row2 = mysqli_fetch_array($result3) ;
				//on cree l'individu avec les informations
	
				$sql = 'INSERT INTO individu(nom,prenom,email,numero,id_annuaire,id_statut) VALUES ("'.$nom.'","'.$prenom.'","'.$email.'","'.$numero.'","'.$row['id_annuaire'].'","'.$row2['id_statut'].'")'; 
				$result = mysqli_query($conn, $sql);
		
		
				//verifier si la requete a bien fonctionné
				if (! empty($result)) {
				
					echo 'vous venez de créer un individu ';
			  
					header('location:Home.html');
				}
			
				else {
					echo '<script type="text/javascript">';
					echo ' alert("Veuillez vérifier les données que vous avez saisi ")';  
					echo '</script>';
			 
			    }
			}
		   
			else {
				echo '<script type="text/javascript">';
				echo ' alert("Cet individu existe déja ")';  
				echo '</script>';
			}
			
		}
			
			


    ?>
		
    </body>
	
	
</html>