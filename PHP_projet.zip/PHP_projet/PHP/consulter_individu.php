<html>
<head>

  <title>Individus</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">
</head>
<body>
	 
		
    <?php
      // Connect to database
		include("db_connect.php");
	  
	  
		$sql1 = 'SELECT o.nom_groupe,a.id_annee,a.niveau FROM groupe o ,annee a where a.id_groupe=o.id_groupe';
        $result1 = mysqli_query($conn, $sql1);
			
		$sql = 'select * from individu '; 
            
        $result = mysqli_query($conn, $sql);
           
    ?>
    <section class = "section">
    <div class = "container"> 
        <table class = "table">
            <thead>
                <tr>
                     <th>Nom</th>
                     <th>Prénom</th>
					 <th>Numero</th>
					 <th>Groupe</th>
					
					 
                </tr>
            </thead>
            <?php while($row = mysqli_fetch_array($result)){
					
			$sql1 = 'SELECT o.nom_groupe FROM groupe o ,annee a where a.id_groupe=o.id_groupe and a.id_annee= "'.$row['id_annee'].'"';
            $result1 = mysqli_query($conn, $sql1);
			$row2 = mysqli_fetch_array($result1);?>
            <tbody>
                <tr>
		
                       
                    <td>  <?php  echo $row['nom']; ?> <br /> </td>
				
                    <td> <?php  echo $row['prenom']; ?> </td>
					<td> <?php  echo $row['numero']; ?> </td>
					<td>  <?php  echo $row2['nom_groupe']; ?> </td>
                     
                </tr>
        
            </tbody>
		<?php } ?>
        </table>
			
		


</body>
</html>