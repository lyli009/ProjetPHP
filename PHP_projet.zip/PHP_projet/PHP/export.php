
<?php

	error_reporting(E_ALL);
	ini_set('display_errors', TRUE);
	ini_set('display_startup_errors', TRUE);
	define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');
	date_default_timezone_set('Europe/London');
	require 'Classes/PHPExcel.php';
	require_once 'Classes/PHPExcel.php';
	require_once 'Classes/PHPExcel/IOFactory.php';
	include ("db_connect.php");

	  
	$annee=$_GET["annee"];
	$groupe=$_GET["groupe"];

	$objPHPExcel = new PHPExcel();

	$objPHPExcel->setActiveSheetIndex(0);
	   
	   
	$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(40);
	$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(40);
	$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(40);
	$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(40);
	$objPHPExcel->getActiveSheet()->getStyle('A')->getAlignment()->setWrapText(true);
	$objPHPExcel->getActiveSheet()->getStyle('B')->getAlignment()->setWrapText(true);
	$objPHPExcel->getActiveSheet()->getStyle('C')->getAlignment()->setWrapText(true);
	$objPHPExcel->getActiveSheet()->getStyle('D')->getAlignment()->setWrapText(true);
	   
	   
	   
	$objPHPExcel->getActiveSheet()->setCellValue('A1', 'nom')
	->setCellValue('B1','prenom')
	->setCellValue('C1','email')
	->setCellValue('D1','numero');
	   
	 $idgroupe = 'select b.id_annee from groupe a, annee b where a.nom_groupe = "'.$groupe.'" and a.id_groupe= b.id_groupe and b.annee = "'.$annee.'" ';
	 $result3 = mysqli_query($conn, $idgroupe);
		 if(mysqli_num_rows($result3) > 0){
					
				   while($row2 = mysqli_fetch_array($result3)){
						$id_annee=$row2['id_annee'];}
					 
					 $reponse ='SELECT nom,prenom,email,numero FROM individu where id_annee = "'.$id_annee.'" ';
					 $result_sql = mysqli_query($conn, $reponse);
					 
					   
					$i=2;
					while( $donnees = mysqli_fetch_assoc($result_sql))
					{
					$nom =  $donnees['nom'];
					$prenom =  $donnees['prenom'];
					$email =  $donnees['email'];
					$numero =  $donnees['numero'];
					   
					$objPHPExcel->getActiveSheet()->setCellValue('A' . $i, "$nom")
					->setCellValue('B' . $i, "$prenom")
					->setCellValue('C' . $i, "$email")
					->setCellValue('D' . $i, "$numero");
					   
					$i++;
					}
					$objPHPExcel->getActiveSheet()->getStyle('A11')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->setAutoFilter($objPHPExcel->getActiveSheet()->calculateWorksheetDimension());
					$objPHPExcel->setActiveSheetIndex(0);
					$callStartTime = microtime(true);
					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
					$objWriter->save(str_replace('.php', '.xls', __FILE__));
					$callEndTime = microtime(true);
					$callTime = $callEndTime - $callStartTime;
					$callStartTime = microtime(true);
					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					ob_end_clean();
					header('Content-type: application/vnd.ms-excel');
					header('Content-Disposition: attachment; filename="Tableau_excel.xls"');        // le nom si tu veut le changer
					$objWriter->save('php://output');
					$callEndTime = microtime(true);
					$callTime = $callEndTime - $callStartTime;
		 }
?>
