
<html>
    <head><title>Modification</title></head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">
    <body>
        
		<form name="inscription" method="post" action="<?php echo "modifier_groupe.php?groupe=".$_GET["groupe"]."&annee=".$_GET["annee"]. ""?>">
         
			<div>
				<label class="label">Groupe</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="groupem"  placeholder="<?php echo $_GET["groupe"] ?> "  />
		    </div>
			<div>
				<label class="label">Année</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="anneen"  placeholder="<?php echo $_GET["annee" ] ?>"  />
		    </div>
			 
			<div>
				<label class="label">Niveau</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="niveaun"  placeholder="<?php echo $_GET["niveau" ] ?>"  />
		    </div>

			<div class="control">
				<button class="button"  name="modifier" >Modifier</button>
			</div>
        </form>
        
		
		
<?php 

	include("db_connect.php");
			
	$annee=$_GET["annee"];
	$groupe=$_GET["groupe"];
		
	if(isset($_POST['modifier'])){
		$groupem=$_POST['groupem'];
		$anneen=$_POST['anneen'];
		$niveaun=$_POST['niveaun'];

		$idgroupe = 'select a.id_groupe from groupe a, annee b where a.nom_groupe = "'.$groupe.'" and a.id_groupe= b.id_groupe and b.annee = "'.$annee.'" ';
		
		$result3 = mysqli_query($conn, $idgroupe);
		  
		if(mysqli_num_rows($result3) > 0)  {
				
			while($row = mysqli_fetch_array($result3)){
				//Vérifier si le groupe existe deja
				if (!empty($groupem)){ 
					//Modifier le nom du groupe
					$sql = 'update groupe set nom_groupe = "'.$groupem.'"  WHERE id_groupe = "'.$row['id_groupe'].'"'; 
					$resultat = mysqli_query($conn, $sql); }
					if ( ($anneen != 0)){
							$sql2='update annee set annee = "'.$anneen.'"  WHERE id_groupe = "'.$row['id_groupe'].'"'; 
							// Exécution de la requête 
							$resultat1 = mysqli_query($conn, $sql2); 
					}
					if (!empty($niveaun)){ 
							$sql3 = 'update annee set niveau = "'.$niveaun.'"  WHERE id_groupe = "'.$row['id_groupe'].'"'; 
							$resultat2 = mysqli_query($conn, $sql3); 
					}
								 
					if ((empty($resultat)) && (empty($resultat1)) && (empty($resultat2))) { 
							echo 'echec'; 
					} 
					else { 
							echo 'modification reussite ';
							header('location:afficher_groupe.php');
								
					}



			   }
		}
   
 
   
 
	}
 ?>
 
</body> 
</html>