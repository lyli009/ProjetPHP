<head>
  <title>Géstion des groupes</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">
  
</head>
<body>
     
<?php
    // Connect to database
    include("db_connect.php");
	//selectionner tous les groupes
    $sql = 'SELECT o.nom_groupe,a.annee,a.niveau FROM groupe o ,annee a where a.id_groupe=o.id_groupe';
    $result = mysqli_query($conn, $sql);
    //tableau d'affichage des groupes   
?>
<section class = "section">
<div class = "container">
    <table class = "table">
        <thead>
            <tr>
                <th>Groupes</th>
                <th>Années</th>
            </tr>
        </thead>
        <?php 
			while ($row = mysqli_fetch_array($result)) { 
					 ?>
                <tbody>
                    <tr>
			
                        <td> <?php echo  $row['nom_groupe']; ?>   </td>
                        <td> <?php  echo $row['annee']; ?> </td>
						
						
                    </tr>
				</tbody>
      <?php } ?>
                
    </table>
		
	
</body>
</html>