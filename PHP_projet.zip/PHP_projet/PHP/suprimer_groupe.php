
<html>
    <head><title>Suppression</title></head>
    <body>
        	
		
<?php 
		
		include("db_connect.php");
        include("afficher_groupe.php");   
		$annee=$_GET["annee"];
	    $groupe=$_GET["groupe"];
		$idgroupe = 'select id_groupe from groupe where nom_groupe = "'.$groupe.'" ';
		$result3 = mysqli_query($conn, $idgroupe);
		if(mysqli_num_rows($result3) > 0){
			while($row = mysqli_fetch_array($result3)){
					
				$sql = 'DELETE FROM annee WHERE id_groupe = "'.$row['id_groupe'].'" and annee = "'.$annee.'"'; 
			   // Exécution de la requête 
					   $resultat = mysqli_query($conn, $sql); 
			   if ($resultat == FALSE) { 
				
					echo '<script type="text/javascript">';
					echo ' alert("Attention le groupe n est pas vide.")'; 
					echo '</script>';
					
			   } 
			   else { 
					$sql2= 'DELETE FROM groupe WHERE id_groupe = "'.$row['id_groupe'].'"';
					$resultat2 = mysqli_query($conn, $sql2); 
					if ($resultat2 == FALSE) { 
							echo "echec de la suppression du groupe .<br />"; 
										} 
					else {    
						echo '<script type="text/javascript">';
						echo ' alert("Le groupe a bien été supprimé.")'; 
						echo '</script>';
					
					}
					

				}
			}
			
		} 
  
   
 


?>
 
 
</body> 
</html>