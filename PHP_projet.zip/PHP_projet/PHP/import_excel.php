
<?php

	include("Classes/PHPExcel/IOFactory.php");
	
	include("db_connect.php");
	
        if (isset($_POST['import'])) {
			
			
			$FileName = $_FILES['file']['name'];
    

        try
        {
            // on crée notre objet xls
            $inputFileType = PHPExcel_IOFactory::identify($FileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($FileName);
        }
        catch(Exception $e)
        {
            // si l'ouverture échoue, on l'indique à l'utilisateur.
            echo "fichier introuvable";
            exit();
        }

        // on crée un tableau qui contiendra les colonnes de notre fichier Excel
        $arrayExcel = [];

        // on séléctionne le bonne feuille du document
        $sheet = $objPHPExcel->getSheet(0);
        // on sauvegarde le nombre de lignes du document.
        $highestRow = $sheet->getHighestRow();
        // on sauvegarde le nombre d colonnes du document.
        $highestColumn = $sheet->getHighestColumn();

        // nous parcourrons les lignes du document.
        for ($row = 2; $row <= $highestRow; $row++)
        {
            // On range la ligne dans l'ordre 'normal'
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                NULL,
                TRUE,
                FALSE);
		
            
		   $iindividu ='select numero from individu where nom = "'.$rowData[0][0].'"  and prenom ="'.$rowData[0][1].'" and numero = "'.$rowData[0][3].'"';
		
		   $result4 = mysqli_query($conn,  $iindividu);
		   
		  
		   if (((mysqli_num_rows($result4) <= 0))) {
			   	  
			$iannuaire = 'select id_annuaire from annuaire  where num_annuaire = "'.$rowData[0][2].'"';
			$result2 = mysqli_query($conn, $iannuaire);
			
			$iannee='select distinct a.id_annee from groupe b,annee a  where b.nom_groupe = "'.$rowData[0][4].'" and a.annee="'.$rowData[0][6].'" and a.niveau= "'.$rowData[0][5].'" and b.id_groupe=a.id_groupe';
			$result3=mysqli_query($conn,$iannee);
		
			
			if ((mysqli_num_rows($result2)) <= 0){
				$sql1='INSERT INTO annuaire(num_annuaire) VALUES ("'.$rowData[0][2].'")';
				$var=mysqli_query($conn, $sql1);
				$iannuaire = 'select id_annuaire from annuaire  where num_annuaire = "'.$rowData[0][2].'"';
				$result2 = mysqli_query($conn, $iannuaire);}
			if (((mysqli_num_rows($result3)) <= 0) && (!empty($rowData[0][4]))) {
				$sql2='INSERT INTO groupe(nom_groupe) VALUES("'.$rowData[0][4].'")';
				$m = mysqli_query($conn,$sql2);
				$iid ='select id_groupe from groupe where nom_groupe = "'.$rowData[0][4].'"';
				$res = mysqli_query($conn,$iid);
				$ress=mysqli_fetch_array($res);
				$sql9='insert into annee(id_groupe,annee,niveau) values("'.$ress['id_groupe'].'","'.$rowData[0][6].'","'.$rowData[0][5].'")';
				$res1=mysqli_query($conn,$sql9);
				$sql8='select id_annee from annee where id_groupe="'.$ress['id_groupe'].'"  and annee="'.$rowData[0][6].'" and niveau="'.$rowData[0][5].'"';
				$result3=mysqli_query($conn,$sql8);
				}
			
					
						
					$row2 = mysqli_fetch_array($result2);
					
					$row3 = mysqli_fetch_array($result3);
					if ((mysqli_num_rows($result3)) <= 0){
						$sql = 'INSERT into individu(nom,prenom,numero,id_annuaire) values("' .$rowData[0][0].'","' .$rowData[0][1].'","' .$rowData[0][3]. '", "'.$row2['id_annuaire'].'")';}
					else
						$sql = 'INSERT into individu(nom,prenom,numero,id_annuaire,id_annee) values("' .$rowData[0][0].'","' .$rowData[0][1].'","' .$rowData[0][3]. '", "'.$row2['id_annuaire'].'","'.$row3['id_annee'].'")';
					$result = mysqli_query($conn, $sql);
			
			if (! empty($result)) {
			  $type = "success";
			  $message = "Les Données sont importées dans la base de données";
			  
			}else {
				echo '<script type="text/javascript">';
				echo ' alert("Erreur")';  
				echo '</script>';
					}
      }
    }
		header('location:Home.html');}	
  

 ?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Import Excel</title>
	</head>

	<body>

		<form action="" method="post" enctype="multipart/form-data">
			<input type="file" name="file">
			<input type="submit" name="import" value="import">
		</form>

	</body>
</html>



        

       