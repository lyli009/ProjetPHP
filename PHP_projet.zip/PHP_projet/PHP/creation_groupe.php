<html>
    <head><title>Ma page d'accueil</title></head>
	<link rel="stylesheet" href="css/formulaire_style.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">
    <body>
        
        <h1 class="title is-2"> Nouveau groupe :</h1>
        <form class="formulaire" name="inscription" method="post" action="creation_groupe.php">
			<div>
				<label class="label">Nom du groupe</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="groupe"  placeholder="Name"  required  />
		    </div>
			<div>
				<label class="label">Année</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="annee"  placeholder="Année"  required  />
		    </div>
			<div>
				<label class="label">Niveau</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="niveau"  placeholder="Niveau"  required  />
		    </div>
	

			<div class="control">
				<button class="button is-primary" name="valider" >Créer</button>
			</div>
        </form>
        <?php
		include("db_connect.php");
		if(isset($_POST['valider'])){
				
            $groupe=$_POST['groupe'];
            $annee=$_POST['annee'];
			$niveau=$_POST['niveau'];
			
			$sqlbis = 'SELECT o.nom_groupe,a.annee FROM groupe o ,annee a where a.annee = "'.$annee.'" and o.nom_groupe = "'.$groupe.'"  and a.id_groupe=o.id_groupe and a.niveau="'.$niveau.'" ';
            $resultbis = mysqli_query($conn, $sqlbis);
			if (mysqli_num_rows($resultbis) > 0){
				echo 'le groupe existe deja';
			}
			if ((mysqli_num_rows($resultbis) <= 0)) {
           
				// si le groupe n'existe pas on l'inserre
				$sql = 'INSERT INTO groupe(nom_groupe) VALUES ("'.$groupe.'")';
			 
				$result = mysqli_query($conn, $sql);
        
				if (! empty($result)) {
								
					$idgroupe = 'select id_groupe from groupe where nom_groupe = "'.$groupe.'" ';
					$result3 = mysqli_query($conn, $idgroupe);
					if(mysqli_num_rows($result3) > 0){
						while($row = mysqli_fetch_array($result3)){
							
							$sql2 = 'INSERT INTO annee(id_groupe,annee,niveau) VALUES ("'.$row['id_groupe'].'","'.$annee.'","'.$niveau.'")';
		  
							$result2 = mysqli_query($conn, $sql2);
						}
					}
		
				
        
					if (! empty($result2)) {
							echo 'groupe créer avec succée ';
							header('location: afficher_groupe.php'  );
		 
        
					} 
					else {
						//creer une alerte dans le cas ou le groupe existe deja
							echo '<script type="text/javascript">';
							echo ' alert("Le groupe existe deja")';  
							echo '</script>';
						}
        
				}
				else  
					echo "ECHEC";
			}
		}
		
    ?>
    </body>
</html>