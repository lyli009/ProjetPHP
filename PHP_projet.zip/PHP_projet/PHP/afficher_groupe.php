<head>
  <title>Géstion des groupes</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">
  <link rel="stylesheet" href="css/style_menu.css">
</head>
<body>
    
	<?php
      // Connect to database
      include("db_connect.php");
	  //selectionner tous les groupes
      $sql = 'SELECT o.nom_groupe,a.annee,a.niveau FROM groupe o ,annee a where a.id_groupe=o.id_groupe';
      $result = mysqli_query($conn, $sql);
        //affichage dans un tableau avec les differentes operations possibles   
    ?>
    <section class = "section">
		<div class = "container">
          
			<table class = "table">
				<thead>
					<tr>
						<th>Groupes</th>
						<th>Années</th>
					</tr>
				</thead>
				<?php 
					while ($row = mysqli_fetch_array($result)) { 
				?>
                <tbody>
                    <tr>
				
                        <td> <a <?php  $groupe=$row['nom_groupe'];
					         $annee=$row['annee']; ?>  href="<?php echo "http://localhost/PHP/afficher_membre_groupe.php?groupe=".$groupe."&annee=".$annee.""?> " > <?php echo  $row['nom_groupe']; ?> </a>  </td>
                       
					   <td> <?php  echo $row['annee']; ?> </td>
						
						<td>
						
							<a <?php   $groupe=$row['nom_groupe'];
					         $annee= $row['annee'];$niveau=$row['niveau']; ?> href="<?php echo "http://localhost/PHP/modifier_groupe.php?groupe=".$groupe."&annee=".$annee."&niveau=".$niveau.""?> "class="button is-primary">
							  Modifier
							</a>
						</td>
						<td>
							<a <?php   $groupe=$row['nom_groupe'];
					         $annee=$row['annee']; ?>  href="<?php echo "http://localhost/PHP/suprimer_groupe.php?groupe=".$groupe."&annee=".$annee.""?> "class="button is-danger">
							 Supprimer
							</a>
						</td>
						<td>
						
							<a <?php   $groupe=$row['nom_groupe'];
							$annee=$row['annee']; ?>   href="<?php echo "http://localhost/PHP/export.php?groupe=".$groupe."&annee=".$annee.""?> "class="button is-primary">
							Exporter
							</a>
						</td>
						<td>
							<ul id="menu-vertical">
								<li> <a href="#" class = "button is-warning" > Membres </a> 
									<ul>
									<li> <a <?php   $groupe=$row['nom_groupe'];
										$annee=$row['annee']; ?>  href="<?php echo "http://localhost/PHP/afficher_individu.php?groupe=".$groupe."&annee=".$annee.""?>" class="button" >
										Ajouter un individu
										</a> 
									</li> 
									<li> <a <?php   $groupe=$row['nom_groupe'];
										$annee=$row['annee']; ?>  href="<?php echo "http://localhost/PHP/suppression_ind_groupe.php?groupe=".$groupe."&annee=".$annee.""?>" class="button" >
										Supprimer un individu
										</a> 
									</li> 
									</ul>
								</li>
					
							</ul>
						</td>
						
						
                        
                    </tr>
            <?php } ?>
                </tbody>
        </table>
			<?php  ?>
		
		<a href="http://localhost/PHP/creation_groupe.php"class="button">
							Nouveau 
		</a>
		<br>
</body>
</html>