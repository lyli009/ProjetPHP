<?php
	//connexion à la base 
	include("db_connect.php");
    include("operations_individu.php");
         
		$numero=$_GET["id_individu"];
	      
			
		//suppression de l'individu 
		$iindividu ='delete from individu where id_individu = "'.$numero.'"';
		
		   $result = mysqli_query($conn, $iindividu);
		  
			echo '<script type="text/javascript">';
			echo ' alert("Supprimé")';  
			echo '</script>';
   
      
			
			 
		   
		
?>
	
	
		
