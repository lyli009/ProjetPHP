
<?php 
			include("db_connect.php");
			include("suppression_ind_groupe.php");
			$annee=$_GET["annee"];
			$groupe=$_GET["groupe"];
			foreach (($_POST['nume']) as $numero)
			{
         
				$idgroupe = 'select b.id_annee from groupe a, annee b where a.nom_groupe = "'.$groupe.'" and a.id_groupe= b.id_groupe and b.annee = "'.$annee.'" ';
				$result3 = mysqli_query($conn, $idgroupe);
				if(mysqli_num_rows($result3) > 0){
				
					while($row = mysqli_fetch_array($result3)){
 						
							$sql = 'select * from individu WHERE id_annee = "'.$row['id_annee'].'" and "'.$numero.'" = id_individu'; 
						// Exécution de la requête 
							$resultat = mysqli_query($conn, $sql); 
							
							$sql2 = 'update individu set id_annee = NULL WHERE id_individu = "'.$numero.'"'; 
							$resultat2 = mysqli_query($conn, $sql2); 
							if ($resultat2 == FALSE) { 
								echo '<script type="text/javascript">';
								echo ' alert("Echec")';  
								echo '</script>'; 
								exit();
							} 
							
							



		        }   
 
			}
			}
				echo '<script type="text/javascript">';
				echo ' alert("Supprimé")';  
				echo '</script>';
				header('location:afficher_groupe');
   
 ?>
 
