<html>
    <head><title>Modification</title></head>
    <body>
        
			<form name="inscription" method="post" action="<?php echo "modifier_un_individu.php?id_individu=".$_GET["id_individu"]."&statut=".$_GET["statut"].""?>" />
         
			<div>
			<label class="label">Nom</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="nomn"  placeholder="<?php echo $_GET["nom"] ?> "  />
		    </div>
			 <div>
			<label class="label">Prénom</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="prenomn"  placeholder="<?php echo $_GET["prenom" ] ?>"  />
		    </div>
			 
			 <div>
			 <label class="label">Email</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="emailn"  placeholder="<?php echo $_GET["email" ] ?>"  />
		    </div>
			<?php 	include("db_connect.php");
			$sql = 'select nom_statut from statut where id_statut ="'.$_GET["statut"].'" '; 
			$con = mysqli_query($conn, $sql );
			$res = mysqli_fetch_array($con); ?>
			
				 <div>
			 <label class="label">Statut</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="statutn"  placeholder="<?php echo $res['nom_statut'] ?>"  />
		    </div>
					
			<div class="control">
				<button class="button"  name="modifier" >Modifier</button>
			</div>
        </form>
        
		
		
<?php 
			include("db_connect.php");
			
			$id=$_GET["id_individu"];
	        
			if(isset($_POST['modifier'])){
					$nom=$_POST['nomn'];
				$prenom=$_POST['prenomn'];
				$email=$_POST['emailn'];
				$statut=$_POST['statutn'];
				
				if (!empty($nom)){
					
					$sql1 = 'update individu set nom = "'.$nom.'"  WHERE id_individu = "'.$id.'"';
					
				   $result1 = mysqli_query($conn, $sql1);
				   if ($result1 == FALSE)
					   echo "echec"; 
				}
					
				if ( !empty($prenom)){
					$sql2 = 'update individu set prenom = "'.$prenom.'"  WHERE id_individu = "'.$id.'"';
				   $result2 = mysqli_query($conn, $sql2);
				   if ($result2 == FALSE)
					echo"echec";
				}	
					
				if ( !empty($email)){
					$sql3 = 'update individu set email = "'.$email.'"  WHERE id_individu = "'.$id.'"';
				   $result3 = mysqli_query($conn, $sql3);
				   if ($result3 == FALSE)
					echo"echec";
				}
				if (!empty($statut)){
					$istatut ='select id_statut from statut  where nom_statut = "'.$statut.'"';
					$result4 = mysqli_query($conn, $istatut);
					if (mysqli_num_rows($result4) <= 0){
						
						$sql4='INSERT INTO statut(nom_statut) VALUES ("'.$statut.'")';
						$var1=mysqli_query($conn, $sql4);
						$istatut ='select id_statut from statut  where nom_statut = "'.$statut.'"';
						$result4 = mysqli_query($conn, $istatut);
					}
					$row2 = mysqli_fetch_array($result4) ;
					$sql4 = 'update individu set id_statut = "'.$row2['id_statut'].'" WHERE id_individu = "'.$id.'"';
					$result5 = mysqli_query($conn, $sql4);
					if ($result5 == FALSE)
						echo"echec";
				}
					
				
				if ((empty($result1)) && (empty($result2))&&(empty($result3)) &&(empty($result4)) ){
					   echo "echec"; 
				}
				else
					echo "Modifier avec succee";
				header('location:operations_individu.php');
		   
		}
			
			
		  
		  
 ?>
 
</body> 
</html>