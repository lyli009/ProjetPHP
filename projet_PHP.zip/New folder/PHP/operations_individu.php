<head>
 
  <title>Individus</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">
</head>

<body>		
    <?php
      // Connect to database
    include("db_connect.php");
	  
	//selectionner tous les individus
			
	$sql = 'select * from individu '; 
            
    $result = mysqli_query($conn, $sql);
           
    ?>
     <section class = "section">
     <div class = "container">
            
     <table class = "table">
      <thead>
        <tr>
            <th>Nom</th>
            <th>Prenom</th>
			<th>Numero</th>
			<th>Groupe</th>
					 
        </tr>
      </thead>
            <?php while($row = mysqli_fetch_array($result)){
			//selectionner tous les groupes
			$sql1 = 'SELECT o.nom_groupe FROM groupe o ,annee a where a.id_groupe=o.id_groupe and a.id_annee= "'.$row['id_annee'].'"';
            $result1 = mysqli_query($conn, $sql1);
			$row2 = mysqli_fetch_array($result1);
			//afficher dans un tableau ?>
                <tbody>
                    <tr>
		
                       
                       <td>  <?php  echo $row['nom']; ?> <br /> </td>
				
                        <td> <?php  echo $row['prenom']; ?> </td>
						<td> <?php  echo $row['numero']; ?> </td>
						<td>  <?php  echo $row2['nom_groupe']; ?> </td>
                     
                        
						<td>
						<a <?php   $numero=$row['id_individu']; $nom=$row['nom'];$prenom=$row['prenom'];$email=$row['email'];$statut=$row['id_statut']
					          ?>  href="<?php echo "http://localhost/PHP/modifier_un_individu.php?id_individu=".$numero."&nom=".$nom."&prenom=".$prenom."&email=".$email."&statut=".$statut.""?> "class="button is-info">
							 Modifier
						</a>
						</td>
						<td>
						<a <?php   $numero=$row['id_individu']; ?>   href="<?php echo "http://localhost/PHP/supprimer_individu.php?id_individu=".$numero.""?> "class="button is-danger">
							 Supprimer
						</a>
						</td>
                    </tr>
          
                </tbody>
			<?php } ?>
        </table>
			
		
</form>

</body>
</html>