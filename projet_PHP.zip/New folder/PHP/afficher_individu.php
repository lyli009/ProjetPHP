<head>
 
  <title>Géstion des individus</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">
</head>

		
    <?php
      // Connect to database
      include("db_connect.php");
	  include("afficher_groupe.php");
	  $annee=$_GET["annee"];
	  $groupe=$_GET["groupe"];
			
		   $idgroupe = 'select b.id_annee from groupe a, annee b where a.nom_groupe = "'.$groupe.'" and a.id_groupe= b.id_groupe and b.annee = "'.$annee.'" ';
		   $result3 = mysqli_query($conn, $idgroupe);
		   if(mysqli_num_rows($result3) > 0){
				
			   while($row2 = mysqli_fetch_array($result3)){
					$id_annee=$row2['id_annee'];
			    }
			$sql = 'select * from individu WHERE  id_annee is NULL'; 
            
            $result = mysqli_query($conn, $sql);
           
    ?>
        <section class = "section">
         <div class = "container">
            
            <table class = "table">
               <thead>
                  <tr>
                     <th>Nom</th>
                     <th>Prenom</th>
					 <th>Numero</th>
                  </tr>
               </thead>
            <?php while ($row = mysqli_fetch_array($result)) { ?>
                <tbody>
                    <tr>
		
                       
                        <td> <form action="<?php echo "affecter_individu_groupe.php?groupe=".$groupe."&annee=".$annee. ""?>" method="post">

 
<input type="checkbox" name="nume[]" value= <?php  echo $row['id_individu']; ?> /> <?php  echo $row['nom']; ?> <br />


   </td>
                        <td> <?php  echo $row['prenom']; ?> </td>
						<td> <?php  echo $row['numero']; ?> </td>
                        
						
                    </tr>
            <?php } ?>
                </tbody>
        </table>
<?php } ?>
		
<input type="submit" value="ajouter">
</form>

</body>
</html>
