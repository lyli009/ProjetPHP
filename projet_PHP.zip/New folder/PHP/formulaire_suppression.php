<html>
    <head><title>Supprimer</title>  
	 <link rel="stylesheet" href="css/formulaire_style.css">
	 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.2/css/bulma.min.css">

	</head>
    <body>
        
        <h1 class="title is-3"> Formulaire de suppréssion </h1>

        <form class ="formulaire" name="inscription" method="post" action="formulaire_suppression.php">
			 <div>
			<label class="label">Nom</label>
			
				<input class="input" type="text"  style="width: 350px; height: 35 px;" name="nom"  placeholder="Name"  required  />
			</div>
			<div>
			 
				<label class="label">Prénom</label>
			
				<input class="input" type="text" style="width: 350px; height: 35 px;"  name="prenom" placeholder="Surname" required />
			</div>
			<div>
				<label class="label">Numero ID</label>
				
				<input class="input" type="text" style="width: 350px; height: 35 px;"  name="numero" placeholder="ID" required />
			</div>
			
				
  <button class="button is-danger" name="supprimer" >Supprimer</button>
</div>
   
        </form>
<?php
		include("db_connect.php");
       
          
			
	      if(isset($_POST['supprimer'])){
          
			$nom=$_POST['nom'];
			$prenom =$_POST['prenom'];
			$numero=$_POST['numero'];
			
			
  
		$iindividu ='select id_individu from individu where nom = "'.$nom.'"  and prenom ="'.$prenom.'" and numero = "'.$numero.'"';
		
		   $result4 = mysqli_query($conn, $iindividu);
		  
		   if ((mysqli_num_rows($result4) > 0)) {
			  
 
			   $row = mysqli_fetch_array($result4);
			 
			
  
			    $iindividu ='delete from individu where id_individu = "'.$row['id_individu'].'"';
		
			    $result = mysqli_query($conn, $iindividu);
		  
		
      
			    if ($result == FALSE) {
				
				echo 'echec '; }
					  
			  
			
				else {
				 echo "suppréssion réussite .<br />";
				 header('location:Home.html');
			   }
		   }
		   else{
			echo '<script type="text/javascript">';
			echo ' alert("Cette individu n existe pas")';  //not showing an alert box.
			echo '</script>';}}
		
?>
	
	
		
</body>
</html>