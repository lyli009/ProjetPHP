		
<?php 
	include("db_connect.php");
			
	include("afficher_individu.php");
			
	$annee=$_GET["annee"]; //recuperer les arguments passés en parametre
			
	$groupe=$_GET["groupe"];
		

    
    foreach (($_POST['nume']) as $num)
    {
	
		// recuperer id_annee pour verifier du groupe
		$idgroupe = 'select b.id_annee from groupe a, annee b where a.nom_groupe = "'.$groupe.'" and a.id_groupe= b.id_groupe and b.annee = "'.$annee.'" ';
		$result3 = mysqli_query($conn, $idgroupe);
		if(mysqli_num_rows($result3) > 0){
				
			   while($row = mysqli_fetch_array($result3)){
 						
								//affectation de l'individu dans le groupe
								$sql2 = 'update individu set id_annee = "'.$row['id_annee'].'" WHERE id_individu = "'.$num.'"'; 
								$resultat2 = mysqli_query($conn, $sql2); 
								if ($resultat2 <= 0){
									echo '<script type="text/javascript">';
									echo ' alert("Erreur")';  
									echo '</script>';
									exit();}
								
								
				}
							



		}
    }
		
									echo '<script type="text/javascript">';
									echo ' alert("OK")';  
									echo '</script>';
									exit();
   
 
 ?>
 
</body> 
</html>